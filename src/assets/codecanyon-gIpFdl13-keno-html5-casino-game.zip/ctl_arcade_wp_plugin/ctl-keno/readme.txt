=== CTL Keno ===
Tags: 	android game, bet, bingo, casino, casino games, chinese gambling games, chinese games, gambling game, instant win, iOS GAME, las vegas, lottery game, poker, slot machine, sweepstakes
Requires at least: 4.3
Tested up to: 4.3

Add Keno to CTL Arcade plugin

== Description ==
Add Keno to CTL Arcade plugin