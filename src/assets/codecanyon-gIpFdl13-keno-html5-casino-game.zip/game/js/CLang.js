TEXT_PRELOADER_CONTINUE = "START";
TEXT_GAMEOVER  = "YOU LOST YOUR CREDITS";
TEXT_CURRENCY  = "$";

TEXT_MIN       = "-";
TEXT_PLUS      = "+";

TEXT_PLAY1     = "PLAY ONE";
TEXT_PLAY5     = "PLAY FIVE";
TEXT_UNDO      = "UNDO";
TEXT_CLEAR     = "CLEAR";

TEXT_PAYOUTS   = "PAYOUTS";
TEXT_HITS      = "HITS";
TEXT_PAYS      = "PAYS";
TEXT_CREDITS_DEVELOPED = "DEVELOPED BY";

TEXT_CONGRATULATIONS = "Congratulations!";
TEXT_SHARE_1 = "You collected <strong>" ;
TEXT_SHARE_2 = " points</strong>!<br><br>Share your score with your friends!";
TEXT_SHARE_3 = "My score is ";
TEXT_SHARE_4 = " points! Can you do better?";
